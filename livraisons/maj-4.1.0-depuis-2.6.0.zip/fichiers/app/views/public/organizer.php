<?php $socIcons = ['instagram' => 'Instagram', 'facebook' => 'Facebook', 'tiktok' => 'TikTok', 'youtube' => 'YouTube', 'spotify' => 'Spotify', 'linkedin' => 'LinkedIn']; ?>
<section class="org-hero<?= !empty($org['cover']) ? ' has-cover' : '' ?>">
  <?php if (!empty($org['cover'])): ?><div class="org-cover"><img src="<?= url($org['cover']) ?>" alt=""></div><?php endif; ?>
  <div class="org-id">
    <div class="org-logo"><?php if ($org['logo']): ?><img src="<?= url($org['logo']) ?>" alt="<?= e($org['name']) ?>"><?php else: ?><span><?= e(mb_strtoupper(mb_substr($org['name'], 0, 1))) ?></span><?php endif; ?></div>
    <div class="org-title">
      <h1><?= e($org['name']) ?></h1>
      <?php if (!empty($org['tagline'])): ?><p class="org-tagline"><?= e($org['tagline']) ?></p><?php endif; ?>
      <div class="org-meta">
        <?php if ($rating['count']): ?><a class="org-rating" href="#avis"><span class="rv-stars" aria-hidden="true"><?= Buyers::stars($rating['avg']) ?></span> <b><?= e(number_format($rating['avg'], 1, ',', '')) ?></b> · <?= $rating['count'] ?> avis</a><?php endif; ?>
        <span><?= (int)$figures['events'] ?> événement<?= $figures['events'] > 1 ? 's' : '' ?></span>
        <?php if ((int)$figures['tickets'] >= 50): ?><span><?= number_format((int)$figures['tickets'], 0, ',', ' ') ?> billets émis</span><?php endif; ?>
      </div>
    </div>
    <div class="org-links">
      <?php foreach ($socials as $k => $u): ?><a class="btn btn-sm btn-light" href="<?= e($u) ?>" target="_blank" rel="noopener"><?= $socIcons[$k] ?? e($k) ?></a><?php endforeach; ?>
      <?php if ($org['website']): ?><a class="btn btn-sm btn-light" href="<?= e($org['website']) ?>" target="_blank" rel="noopener">Site web</a><?php endif; ?>
      <details class="follow-pop"><summary class="btn btn-sm">Suivre</summary><form method="post" action="<?= url('/o/' . $org['slug'] . '/suivre') ?>" class="card stack"><?= csrf_field() ?><small class="muted">Un e-mail dès qu'une nouvelle date est mise en vente.</small><input type="email" name="email" placeholder="Ton e-mail" required><button class="btn btn-sm">Me prévenir</button></form></details>
    </div>
  </div>
  <?php if ($org['description']): ?><p class="org-about"><?= nl2br(e($org['description'])) ?></p><?php endif; ?>
  <?php $hasPass = (bool)val('SELECT 1 FROM pass_types WHERE organizer_id = ? AND active = 1 LIMIT 1', [$org['id']]); $hasShop = !empty($org['shop_enabled']) && val('SELECT 1 FROM shop_products WHERE organizer_id = ? AND active = 1 LIMIT 1', [$org['id']]);
  if ($hasPass || !empty($org['gift_enabled']) || $hasShop): ?>
  <div class="org-store">
    <?php if ($hasPass): ?><a class="btn btn-light" href="<?= url('/o/' . $org['slug'] . '/abonnements') ?>"><?= ui_icon('ticket', 18) ?> Abonnements</a><?php endif; ?>
    <?php if (!empty($org['gift_enabled'])): ?><a class="btn btn-light" href="<?= url('/o/' . $org['slug'] . '/cartes-cadeaux') ?>"><?= ui_icon('gift', 18) ?> Offrir une carte cadeau</a><?php endif; ?>
    <?php if ($hasShop): ?><a class="btn btn-light" href="<?= url('/o/' . $org['slug'] . '/boutique') ?>"><?= ui_icon('bag', 18) ?> Boutique</a><?php endif; ?>
  </div>
  <?php endif; ?>
  <?php if ((int)($org['lost_enabled'] ?? 1) && val('SELECT id FROM events WHERE organizer_id = ? AND starts_at < NOW() LIMIT 1', [$org['id']])): ?><p class="org-lost"><a href="<?= url('/o/' . $org['slug'] . '/objets-trouves') ?>">Objet perdu lors d'un événement ?</a></p><?php endif; ?>
</section>
<?php $siteOn = class_exists('Site') && Site::on($org); $siteS = $siteOn ? Site::settings($org) : [];
if ($siteOn && trim((string)$siteS['intro']) !== ''): ?><section class="site-intro prose"><?= rich_text((string)$siteS['intro']) ?></section><?php endif; ?>
<h2 class="org-h">À venir</h2>
<?php if (!$events): ?><div class="card empty">Aucun événement en vente pour le moment.</div>
<?php else: ?><div class="events-grid"><?php foreach ($events as $ev) echo view('partials/event_card', ['ev' => $ev]); ?></div><?php endif; ?>
<?php if ($past): ?>
<h2 class="org-h">Déjà passés</h2>
<div class="events-grid past-grid"><?php foreach ($past as $ev) echo view('partials/event_card', ['ev' => $ev]); ?></div>
<?php endif; ?>
<?php if ($reviews): ?>
<h2 id="avis" class="org-h">Ce qu'en disent les participants</h2>
<div class="rv-public">
<?php foreach ($reviews as $r): ?>
  <figure class="card rv-quote">
    <span class="rv-stars" aria-label="<?= (int)$r['rating'] ?> sur 5"><?= Buyers::stars((float)$r['rating']) ?></span>
    <blockquote><?= nl2br(e($r['comment'])) ?></blockquote>
    <figcaption><b><?= e($r['author'] ?: 'Un·e participant·e') ?></b><?= $r['verified'] ? ' · venu·e' : '' ?><br><small class="muted"><?= e($r['ev_name']) ?></small></figcaption>
    <?php if ($r['reply']): ?><div class="rv-org-reply"><b><?= e($org['name']) ?></b><p><?= nl2br(e($r['reply'])) ?></p></div><?php endif; ?>
  </figure>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php if ($siteOn && $siteS['news_home'] && ($news = Site::news((int)$org['id'], 3))): ?>
<div class="row between org-h-row"><h2 class="org-h">Actualités</h2><a href="<?= url('/o/' . $org['slug'] . '/actualites') ?>">Toutes les actualités ›</a></div>
<div class="news-grid"><?php foreach ($news as $n) echo view('public/_news_card', ['n' => $n, 'org' => $org]); ?></div>
<?php endif; ?>
