<?php
$anyOnSale = (bool)array_filter($rates, fn($r) => $r['sale']['ok']);
$useDrawer = !$seatmap && $anyOnSale && empty($cart['partner']);
$hasCodes = (bool)val('SELECT COUNT(*) FROM promos WHERE event_id = ? AND active = 1', [$ev['id']]);
$addr = trim($ev['venue'] . ' ' . $ev['address'] . ' ' . $ev['city']);
$base = '/e/' . $ev['slug'];
$jours = ['dim.', 'lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.'];
$moisC = ['', 'janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
$mois = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
// relief : compte à rebours, places restantes, prix d'appel pour la barre mobile
$startAt = $session['starts_at'] ?? ($sessions ? $sessions[0]['starts_at'] : $ev['starts_at']);
$startTs = strtotime((string)$startAt);
$showCountdown = $startTs > time() && $startTs - time() < 90 * 86400;
$capTotal = Tickets::capacity($ev, $session ?? null);
$capLeft = $capTotal > 0 ? max(0, $capTotal - Tickets::eventUsed((int)$ev['id'], isset($session) && $session ? (int)$session['id'] : null)) : null;
$scarce = $capLeft !== null && $capLeft > 0 && $capLeft <= max(10, (int)ceil($capTotal * 0.15));
$onSalePrices = array_map(fn($r) => (int)$r['price'], array_filter($rates, fn($r) => $r['sale']['ok']));
$fromPrice = $onSalePrices ? min($onSalePrices) : null;
?>
<?php if ($ev['status'] === 'draft'): ?><div class="flash warning">Aperçu : cet événement est en brouillon. Toi seul le vois.</div><?php endif; ?>
<div class="event-top reveal">
  <div class="event-poster"><?php if ($ev['image']): ?><img src="<?= url($ev['image']) ?>" alt="<?= e($ev['name']) ?>"><?php endif; ?></div>
  <div>
    <span class="eyebrow"><?= e($org['name']) ?><?= $ev['category'] ? ' · ' . e($ev['category']) : '' ?></span>
    <h1 class="event-title"><?= e($ev['name']) ?></h1>
    <div class="event-pills">
      <?php if ($showCountdown): ?><span class="pill pill-dark" data-countdown="<?= e(date('c', $startTs)) ?>"><span data-cd-text><?= e(ago_until($startTs)) ?></span></span><?php endif; ?>
      <?php if ($scarce): ?><span class="pill pill-hot">Plus que <?= (int)$capLeft ?> place<?= $capLeft > 1 ? 's' : '' ?></span><?php elseif ($capLeft === 0 && $capTotal > 0): ?><span class="pill">Complet</span><?php endif; ?>
      <?php $orgRating = Buyers::orgRating((int)$org['id']); if ($orgRating['count'] >= 3): ?><a class="pill pill-soft" href="<?= url('/o/' . $org['slug']) ?>#avis"><?= e(number_format($orgRating['avg'], 1, ',', '')) ?>/5 · <?= $orgRating['count'] ?> avis sur l'organisateur</a><?php endif; ?>
      <?php if (!empty($ev['min_age'])): ?><span class="pill pill-age"><?= (int)$ev['min_age'] ?> ans et +</span><?php endif; ?>
      <?php $tiersP = Tickets::tiers($ev); if ($tiersP && $anyOnSale): ?><span class="pill pill-soft"><?= count($tiersP) > 1 ? 'Jusqu\'à ' : '' ?>−<?= (int)end($tiersP)['pct'] ?> % en groupe</span><?php endif; ?>
      <?php if ($fromPrice !== null): ?><span class="pill pill-soft"><?= $fromPrice === 0 ? 'Gratuit' : 'Dès ' . e(money($fromPrice)) ?></span><?php endif; ?>
    </div>
    <dl class="event-facts">
      <div class="fact"><dt>Quand</dt><dd>
        <?php if ($sessions): ?><b><?= count($sessions) ?> date<?= count($sessions) > 1 ? 's' : '' ?></b><span class="muted">du <?= e(fr_date($sessions[0]['starts_at'], false)) ?> au <?= e(fr_date(end($sessions)['starts_at'], false)) ?></span>
        <?php else: ?><b><?= e(fr_date($ev['starts_at'])) ?></b><?php if ($ev['ends_at']): ?><span class="muted">jusqu'au <?= e(fr_date($ev['ends_at'])) ?></span><?php endif; ?><?php endif; ?>
      </dd></div>
      <?php if ($addr !== ''): ?>
      <div class="fact"><dt>Où</dt><dd><b><?= e($ev['venue'] ?: $ev['city']) ?></b><span class="muted"><?= e(trim($ev['address'] . ' ' . $ev['city'])) ?></span><br><a href="https://www.google.com/maps/search/?api=1&amp;query=<?= urlencode($addr) ?>" target="_blank" rel="noopener">Y aller</a></dd></div>
      <?php endif; ?>
      <div class="fact"><dt>Par</dt><dd><a href="<?= url('/o/' . $org['slug']) ?>"><?= e($org['name']) ?></a></dd></div>
    </dl>
    <?php if ((int)($ev['show_going'] ?? 0) && ($gg = Social::going($ev)) && $gg['total'] >= 3): ?>
      <div class="going"><div class="going-av"><?php foreach (array_slice($gg['people'], 0, 6) as $nm): ?><span title="<?= e($nm) ?>"><?= e(mb_strtoupper(mb_substr($nm, 0, 1))) ?></span><?php endforeach; ?></div>
        <div><b><?= $gg['people'] ? e(implode(', ', array_slice($gg['people'], 0, 3))) . ($gg['total'] > 3 ? ' et ' . number_format($gg['total'] - min(3, count($gg['people'])), 0, ',', ' ') . ' autres' : '') : number_format($gg['total'], 0, ',', ' ') . ' personnes' ?></b> <small>y vont</small></div></div>
    <?php endif; ?>
    <?php if (!empty($ev['volunteer_recruit'])): ?><a class="vol-cta" href="<?= url('/e/' . $ev['slug'] . '/benevoles') ?>">On cherche des bénévoles : rejoins l'équipe →</a><?php endif; ?>
    <a class="btn btn-lg" href="#billets" <?= $useDrawer ? 'data-dw-open' : '' ?>><?= $sessions && !$session ? 'Choisir ma date' : 'Je réserve' ?></a>
    <div class="ev-actions"><button type="button" class="soon-chip fav-btn" data-fav="<?= (int)$ev['id'] ?>" aria-pressed="false">Favori</button><details class="cal-menu"><summary class="soon-chip">Agenda</summary><div class="cal-pop"><a href="<?= e(Buyers::googleUrl($ev, $session ?? null)) ?>" target="_blank" rel="noopener">Google Agenda</a><a href="<?= e(Buyers::icsUrl($ev, $session ?? null)) ?>">Apple / Outlook (.ics)</a></div></details><a class="soon-chip" href="<?= url('/e/' . $ev['slug'] . '/covoiturage') ?>">Covoiturage</a></div>
  </div>
</div>

<div class="event-layout">
  <div>
    <?php if ($sessions): ?>
      <h2 id="dates">Choisis ta date</h2>
      <div class="sessions">
        <?php $month = null; foreach ($sessions as $x): $t = strtotime($x['starts_at']); $m = date('Y-m', $t); ?>
          <?php if ($m !== $month): $month = $m; ?><div class="sessions-month"><?= $mois[(int)date('n', $t)] ?> <?= date('Y', $t) ?></div><?php endif; ?>
          <a class="session <?= $session && (int)$session['id'] === (int)$x['id'] ? 'on' : '' ?> <?= $x['left'] === 0 ? 'full' : '' ?>" href="<?= url($base, ['seance' => $x['id']]) ?>#billets">
            <span class="session-day"><b><?= date('j', $t) ?></b><?= $moisC[(int)date('n', $t)] ?></span>
            <span class="session-info"><b><?= $jours[(int)date('w', $t)] ?> <?= date('H:i', $t) ?></b><?= $x['label'] ? '<small>' . e($x['label']) . '</small>' : '' ?></span>
            <span class="session-left"><?= $x['left'] === null ? '' : ($x['left'] === 0 ? 'Complet' : ($x['left'] <= 20 ? '' . $x['left'] . ' places' : 'Dispo')) ?></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php $prog = json_decode((string)($ev['program'] ?? ''), true) ?: []; $faq = json_decode((string)($ev['faq'] ?? ''), true) ?: []; $prac = json_decode((string)($ev['practical'] ?? ''), true) ?: []; ?>
    <?php if ($ev['description']): ?><h2 class="mt"><?= $prog ? 'L\'événement' : 'Le programme' ?></h2><div class="prose"><?= e($ev['description']) ?></div><?php endif; ?>
    <?php if ($pbl = PageBlocks::get($ev)): ?><div class="pb-wrap"><?= view('public/_blocks', ['ev' => $ev, 'blocks' => $pbl]) ?></div><?php endif; // 4.1 : page par blocs ?>
    <?php if ($prog): ?>
      <section class="ev-section"><h2>Programme</h2>
        <ol class="timeline"><?php foreach ($prog as $p): ?><li><span class="tl-time"><?= e($p['when'] ?? '') ?></span><div><b><?= e($p['title'] ?? '') ?></b><?php if (!empty($p['text'])): ?><p><?= e($p['text']) ?></p><?php endif; ?></div></li><?php endforeach; ?></ol>
      </section>
    <?php endif; ?>
    <?php $pracLabels = ['acces' => ['pin', 'Venir'], 'parking' => ['cart', 'Stationnement'], 'pmr' => ['users', 'Accessibilité'], 'regles' => ['shield', 'À savoir'], 'food' => ['store', 'Bar & restauration'], 'contact' => ['mail', 'Contact']]; $pracShown = array_filter($pracLabels, fn($k) => trim((string)($prac[$k] ?? '')) !== '', ARRAY_FILTER_USE_KEY); ?>
    <?php if ($pracShown): ?>
      <section class="ev-section"><h2>Infos pratiques</h2>
        <div class="prac-grid"><?php foreach ($pracShown as $k => [$ic, $lab]): ?><div class="prac"><span class="prac-ico"><?= ui_icon($ic) ?></span><div><b><?= $lab ?></b><p><?= nl2br(e((string)$prac[$k])) ?></p></div></div><?php endforeach; ?></div>
      </section>
    <?php endif; ?>
    <?php if ($faq): ?>
      <section class="ev-section"><h2>Questions fréquentes</h2>
        <div class="faq"><?php foreach ($faq as $q): ?><details><summary><?= e($q['q'] ?? '') ?></summary><p><?= nl2br(e($q['a'] ?? '')) ?></p></details><?php endforeach; ?></div>
        <script type="application/ld+json"><?= json_encode(['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => array_map(fn($q) => ['@type' => 'Question', 'name' => $q['q'] ?? '', 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $q['a'] ?? '']], $faq)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
      </section>
    <?php endif; ?>
    <?php if ($resales): ?>
      <h2 class="mt">Bourse aux billets officielle</h2>
      <p class="muted">Des billets revendus par d'autres spectateurs, au prix d'origine (jamais plus cher). Un nouveau QR code à ton nom est émis.</p>
      <div class="resale-list">
        <?php foreach ($resales as $x): ?>
          <div class="resale-item"><span><b><?= e($x['rate_name']) ?></b><?= $x['seat'] ? '<small>' . e(Seating::label($x['seat'], Seating::map($ev))) . '</small>' : '' ?></span><span class="rate-price"><?= e(money((int)$x['price'])) ?></span><a class="btn btn-sm" href="<?= url('/revente/' . $x['id']) ?>">Racheter</a></div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <aside class="buy-box" id="billets">
    <?php if (!empty($ev['_presale_locked'])): $open = strtotime((string)$ev['presale_until']); ?>
      <div class="presale-box">
        <span class="bl-eyebrow">Prévente privée</span>
        <h2>Les billets sont réservés aux invités jusqu'au <?= e(fr_date((string)$ev['presale_until'])) ?></h2>
        <p class="presale-cd" data-countdown="<?= e(date('c', $open)) ?>" data-cd-end="C'est ouvert ! Recharge la page.">Ouverture au public · <span data-cd-text><?= e(ago_until($open)) ?></span></p>
        <p>Tu es <?= !empty($ev['presale_past']) ? 'un·e habitué·e' : 'sur la liste' ?> ? Entre ton e-mail, on t'envoie ton lien d'accès.</p>
        <form method="post" action="<?= url('/e/' . $ev['slug'] . '/prevente') ?>" class="presale-form"><?= csrf_field() ?><input type="email" name="email" required placeholder="ton@email.fr" aria-label="Ton e-mail" autocomplete="email"><button class="btn">Recevoir mon accès</button></form>
      </div>
    <?php endif; ?>
    <?php if (RatesPlus::launchPending($ev)): $lt = strtotime((string)$ev['on_sale_at']); $nAl = (int)val('SELECT COUNT(*) FROM sale_alerts WHERE event_id = ?', [$ev['id']]); ?>
      <div class="launch-box">
        <span class="bl-eyebrow">Ouverture de la billetterie</span>
        <h2><?= e(fr_date((string)$ev['on_sale_at'])) ?></h2>
        <div class="launch-cd" data-launch="<?= e(date('c', $lt)) ?>"><div><b data-u="d">0</b><small>jours</small></div><div><b data-u="h">0</b><small>heures</small></div><div><b data-u="m">0</b><small>min</small></div><div><b data-u="s">0</b><small>s</small></div></div>
        <form method="post" action="<?= url('/e/' . $ev['slug'] . '/alerte') ?>" class="presale-form"><?= csrf_field() ?><input type="email" name="email" required placeholder="ton@email.fr" aria-label="Ton e-mail" autocomplete="email"><button class="btn">Préviens-moi</button></form>
        <small class="muted"><?= $nAl >= 10 ? number_format($nAl, 0, ',', ' ') . ' personnes attendent déjà l\'ouverture. ' : '' ?>Un e-mail à la minute où ça ouvre, rien d'autre.</small>
      </div>
      <script>(function(){var el=document.querySelector('[data-launch]');if(!el)return;var t=new Date(el.dataset.launch).getTime();function tick(){var d=Math.max(0,t-Date.now());if(d<=0){location.reload();return}var s=Math.floor(d/1000);el.querySelector('[data-u=d]').textContent=Math.floor(s/86400);el.querySelector('[data-u=h]').textContent=Math.floor(s%86400/3600);el.querySelector('[data-u=m]').textContent=Math.floor(s%3600/60);el.querySelector('[data-u=s]').textContent=s%60}tick();setInterval(tick,1000)})();</script>
    <?php endif; ?>
    <?php if ($useDrawer): $onSale = array_values(array_filter($rates, fn($r) => $r['sale']['ok'])); ?>
      <div class="buy-launch" hidden>
        <div class="bl-top"><span class="bl-eyebrow">Billetterie ouverte</span><b><?= $fromPrice === 0 ? 'Gratuit' : 'Dès ' . e(money((int)$fromPrice)) ?></b><?php if ($session): ?><small><?= e(fr_date($session['starts_at'])) ?></small><?php endif; ?></div>
        <ul class="bl-rates"><?php foreach (array_slice($onSale, 0, 4) as $r): ?><li><span><?= e($r['name']) ?></span><b><?= $r['price_mode'] === 'free' ? 'Prix libre' : ((int)$r['price'] ? e(money((int)$r['price'])) : 'Gratuit') ?></b></li><?php endforeach; ?>
          <?php if (count($onSale) > 4): ?><li class="muted">+ <?= count($onSale) - 4 ?> autre(s) tarif(s)</li><?php endif; ?></ul>
        <button type="button" class="btn btn-lg btn-block" data-dw-open>Réserver mes billets →</button>
        <p class="secure-note">Paiement sécurisé · billets par e-mail · <?= $org['fee_mode'] === 'buyer' ? 'frais affichés avant de payer' : 'prix tout compris' ?></p>
        <?php if ((int)($ev['installments'] ?? 1) && ($bn = Payments::installmentsLabel())): ?><p class="bnpl-note"><?= ui_icon('euro', 16) ?> <?= e($bn) ?></p><?php endif; ?>
      </div>
    <?php endif; ?>
    <?php if ($sessions && !$session): ?>
      <div class="tickets-box"><div class="tickets-box-head"><h2>Billets</h2></div><div class="rate"><span class="muted">Choisis d'abord une date dans la liste.</span></div></div>
    <?php else: ?>
    <?php [$fpct, $ffix] = Tickets::feeRates($org); ?>
    <form class="tickets-box" method="post" id="buy" action="<?= url($base) ?>" data-seatmap="<?= $seatmap ? url($base . '/plan') : '' ?>" data-fee-pct="<?= $org['fee_mode'] === 'buyer' ? e((string)$fpct) : '0' ?>" data-fee-fixed="<?= $org['fee_mode'] === 'buyer' ? (int)$ffix : 0 ?>" data-tiers="<?= e(json_encode(empty($cart['partner']) ? Tickets::tiers($ev) : [])) ?>"><?= csrf_field() ?>
      <div class="tickets-box-head"><h2>Billets</h2><small><?= $session ? e(fr_date($session['starts_at'])) : ($org['fee_mode'] === 'buyer' ? 'Frais inclus dans le total' : 'Prix tout compris') ?></small></div>
      <?php if ($cart['waitlist']): ?><div class="applied-code"><span>Place réservée pour toi (liste d'attente)</span></div><?php endif; ?>
      <?php if (!$rates): ?><div class="rate"><span class="muted">Pas encore de billets. Patience…</span></div><?php endif; ?>
      <?php foreach ($rates as $r):
          $fee = Tickets::unitFee($org, (int)$r['price']);
          $max = $r['sale']['ok'] ? min(50, (int)$r['sale']['remaining'], (int)$r['max_per_order'] ?: 50, (int)$ev['max_per_order'] ?: 50) : 0;
          $pack = max(1, (int)$r['pack_size']); $free = $r['price_mode'] === 'free'; ?>
        <div class="rate <?= $r['sale']['ok'] ? '' : 'off' ?>">
          <div class="rate-info">
            <b><?= e($r['name']) ?><?php if (!empty($r['badge'])): ?><span class="rate-badge"><?= e($r['badge']) ?></span><?php endif; ?></b>
            <?php if ($r['description']): ?><small><?= e($r['description']) ?></small><?php endif; ?>
            <?php if (!empty($r['proof']) && !str_contains((string)$r['description'], (string)$r['proof'])): ?><small class="rate-proof">Justificatif demandé à l'entrée : <?= e($r['proof']) ?></small><?php endif; ?>
            <?php if (!empty($r['left_label'])): ?><span class="rate-left"><?= e($r['left_label']) ?></span><?php endif; ?>
            <?php if ((int)($r['min_per_order'] ?? 0) > 1): ?><small>Par <?= (int)$r['min_per_order'] ?> minimum</small><?php endif; ?>
            <?php if ($pack > 1): ?><small>Pack de <?= $pack ?> billets</small><?php endif; ?>
            <?php if ((int)($r['min_age'] ?? 0) > (int)($ev['min_age'] ?? 0)): ?><small>Réservé aux <?= (int)$r['min_age'] ?> ans et +</small><?php endif; ?>
            <?php if ((int)$r['max_entries'] > 1 || $r['per_day']): ?><small><?= $r['per_day'] ? '1 entrée par jour' : (int)$r['max_entries'] . ' entrées' ?></small><?php endif; ?>
            <?php $isEarly = $r['sale']['ok'] && (bool)array_filter($rates, fn($x) => (int)($x['after_rate_id'] ?? 0) === (int)$r['id']);
                  $endSoon = $r['sale']['ok'] && $r['sale_end'] && strtotime($r['sale_end']) - time() < 7 * 86400; ?>
            <?php if (!empty($r['sale']['next'])): ?><span class="rate-tag tier-next"><?= e($r['sale']['why']) ?></span>
            <?php elseif (!$r['sale']['ok']): ?><span class="rate-tag" style="color:var(--muted)"><?= e($r['sale']['why']) ?></span>
            <?php elseif ($isEarly || $endSoon): ?>
              <?php if ($isEarly): ?><span class="rate-tag tier-early">Prix early bird<?= (int)$r['quota'] && $r['sale']['remaining'] <= max(10, (int)ceil((int)$r['quota'] * 0.25)) ? ' · plus que ' . (int)$r['sale']['remaining'] . ' à ce prix' : '' ?></span><?php endif; ?>
              <?php if ($endSoon): ?><span class="rate-tag tier-end" data-countdown="<?= e(date('c', strtotime($r['sale_end']))) ?>" data-cd-end="Prix terminé">Ce prix s'arrête · <span data-cd-text><?= e(ago_until(strtotime($r['sale_end']))) ?></span></span><?php endif; ?>
            <?php elseif ($r['sale']['remaining'] <= 10 && empty($r['left_label'])): ?><span class="rate-tag">Plus que <?= (int)$r['sale']['remaining'] ?></span>
            <?php elseif ($r['hidden']): ?><span class="rate-tag" style="color:var(--primary)">Tarif secret débloqué</span><?php endif; ?>
            <?php if ($free && $max > 0): ?><label class="free-price">Ton prix (min. <?= e(money((int)$r['price'])) ?>) <span class="input-suffix"><input name="price[<?= (int)$r['id'] ?>]" value="<?= e(money_input(max((int)$r['price'], (int)($cart['prices'][$r['id']] ?? $r['price'])))) ?>" inputmode="decimal" data-free="<?= (int)$r['id'] ?>"><span>€</span></span></label><?php endif; ?>
          </div>
          <div class="rate-price"><?= $free ? 'Prix libre' : ((int)$r['price'] === 0 ? 'Gratuit' : e(money((int)$r['price']))) ?><?php if ($fee && !$free): ?><small>+ <?= e(money($fee)) ?> de frais</small><?php endif; ?>
            <?php if (!$free && $r['sale']['ok'] && ($dst = DynPrice::state($r)) && $dst['next'] !== null): ?><small class="dyn-next"><?= e(DynPrice::label($dst)) ?></small><?php endif; ?></div>
          <?php if ($max > 0): ?>
          <div class="qty" data-base="<?= (int)$r['price'] ?>" data-unit="1" data-price="<?= (int)$r['price'] + $fee ?>" data-rate="<?= (int)$r['id'] ?>" data-pack="<?= $pack ?>" data-cat="<?= e((string)$r['seat_category']) ?>" data-name="<?= e($r['name']) ?>" <?= $free ? 'data-freeprice="1"' : '' ?>>
            <button type="button" data-d="-1" aria-label="Moins">−</button>
            <input type="number" name="qty[<?= (int)$r['id'] ?>]" value="<?= (int)($cart['q'][$r['id']] ?? 0) ?>" min="0" max="<?= $max ?>" inputmode="numeric" aria-label="Quantité <?= e($r['name']) ?>">
            <button type="button" data-d="1" aria-label="Plus">+</button>
          </div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>

      <?php if ($seatmap && $anyOnSale): ?>
        <div class="seat-zone">
          <div class="row between"><b>Tes places</b><small id="seat-count"></small></div>
          <div id="seat-picked" class="seat-picked muted">Choisis tes billets, puis clique sur les places du plan.</div>
          <button type="button" class="btn btn-ghost btn-block btn-sm" id="seat-open">Ouvrir le plan de salle</button>
          <div id="seat-inputs"></div>
        </div>
      <?php endif; ?>

      <?php if ($products && $anyOnSale): ?>
        <div class="extras-head">Options</div>
        <?php foreach ($products as $p): $pmax = min(20, $p['left'] === PHP_INT_MAX ? 20 : (int)$p['left'], (int)$p['max_per_order'] ?: 20); ?>
          <div class="rate">
            <div class="rate-info"><b><?= e($p['name']) ?></b><?php if ($p['description']): ?><small><?= e($p['description']) ?></small><?php endif; ?><?php if ($pmax <= 0): ?><span class="rate-tag" style="color:var(--muted)">Épuisé</span><?php endif; ?></div>
            <div class="rate-price"><?= e(money((int)$p['price'])) ?></div>
            <?php if ($pmax > 0): ?><div class="qty" data-base="<?= (int)$p['price'] ?>" data-price="<?= (int)$p['price'] ?>"><button type="button" data-d="-1">−</button><input type="number" name="product[<?= (int)$p['id'] ?>]" value="<?= (int)($cart['products'][$p['id']] ?? 0) ?>" min="0" max="<?= $pmax ?>"><button type="button" data-d="1">+</button></div>
              <?php $vars = array_filter(array_map('trim', explode(',', (string)($p['variants'] ?? '')))); if ($vars): ?><label class="variant-pick">Taille / modèle <select name="variant[<?= (int)$p['id'] ?>]"><?php foreach ($vars as $v): ?><option <?= ($cart['variants'][$p['id']] ?? '') === $v ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></label><?php endif; ?>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>

      <?php if ($ev['donation_enabled'] && $anyOnSale): ?>
        <div class="rate"><div class="rate-info"><b><?= e($ev['donation_label'] ?: 'Un petit don pour soutenir ?') ?></b><small>Facultatif, 100 % pour l'organisateur.</small></div>
          <span class="input-suffix" style="width:110px"><input name="donation" value="<?= $cart['donation'] ? e(money_input((int)$cart['donation'])) : '' ?>" placeholder="0,00" inputmode="decimal" id="donation"><span>€</span></span></div>
      <?php endif; ?>

      <?php if ($promo): ?>
        <div class="applied-code"><span>Code <?= e($promo['code']) ?> : <?= $promo['kind'] === 'percent' ? '−' . (int)$promo['value'] . ' %' : '−' . e(money((int)$promo['value'])) . ' par billet' ?></span>
        <button class="linklike" name="action" value="remove_code" formnovalidate>retirer</button></div>
      <?php endif; ?>
      <?php if ($anyOnSale): ?>
        <div class="buy-foot">
          <div class="buy-total"><span>Total</span><span id="buy-total">0,00 €</span></div>
          <button class="btn btn-block btn-lg" name="action" value="buy">C'est parti →</button>
          <p class="secure-note">Paiement sécurisé. Tes billets arrivent direct par e-mail.</p>
          <?php if ((int)($ev['installments'] ?? 1) && ($bn = Payments::installmentsLabel())): ?><p class="bnpl-note"><?= ui_icon('euro', 16) ?> <?= e($bn) ?></p><?php endif; ?>
        </div>
      <?php endif; ?>
    </form>
    <?php if ((int)($ev['group_buy'] ?? 0) && $anyOnSale): $grpRates = array_filter($rates, fn($r) => $r['sale']['ok'] && !$r['hidden'] && $r['price_mode'] !== 'free'); if ($grpRates): ?>
    <details class="card group-buy"><summary>Payer à plusieurs : chacun paie sa place</summary>
      <form method="post" action="<?= url('/e/' . $ev['slug'] . '/bande') ?>"><?= csrf_field() ?><?php if ($session): ?><input type="hidden" name="session_id" value="<?= (int)$session['id'] ?>"><?php endif; ?>
        <small class="muted">On bloque les places 24 h pour ta bande. Tu partages le lien, chacun paie la sienne (toi aussi).</small>
        <div class="grid2"><select name="rate_id"><?php foreach ($grpRates as $r): ?><option value="<?= (int)$r['id'] ?>"><?= e($r['name']) ?> · <?= e(money((int)$r['price'])) ?></option><?php endforeach; ?></select><select name="qty"><?php for ($i = 2; $i <= 12; $i++): ?><option value="<?= $i ?>" <?= $i === 4 ? 'selected' : '' ?>><?= $i ?> personnes</option><?php endfor; ?></select></div>
        <div class="grid2"><input name="name" placeholder="Ton prénom" required><input type="email" name="email" placeholder="Ton e-mail" required></div>
        <button class="btn">Bloquer les places</button></form></details>
    <?php endif; endif; ?>
    <?php if (($hasCodes || !empty($org['gift_enabled'])) && $anyOnSale): ?>
    <form method="post" action="<?= url($base) ?>"><?= csrf_field() ?>
      <details class="code-box"><summary>T'as un code ?</summary>
        <div class="row" style="margin-top:12px;flex-wrap:nowrap;gap:0"><input type="text" name="code" placeholder="CODE" style="text-transform:uppercase" required aria-label="Code"><button class="btn" name="action" value="code">OK</button></div>
      </details>
    </form>
    <?php endif; ?>
    <?php if ($soldOut && $ev['waitlist_enabled']): ?>
      <form class="card waitlist-box" method="post" action="<?= url($base . '/attente') ?>"><?= csrf_field() ?>
        <h3>Complet… mais pas fini !</h3>
        <p class="muted" style="font-size:14.5px">Inscris-toi sur la liste d'attente : si une place se libère, la première personne inscrite la reçoit par e-mail et on la lui garde <?= Waitlist::hours($ev) ?> h.</p>
        <div class="grid2"><input name="first_name" placeholder="Prénom"><input name="last_name" placeholder="Nom"></div>
        <div class="row mt" style="flex-wrap:nowrap;gap:0"><input type="email" name="email" placeholder="ton@email.fr" required><select name="qty" style="width:90px"><?php for ($i = 1; $i <= 6; $i++): ?><option value="<?= $i ?>"><?= $i ?> pl.</option><?php endfor; ?></select></div>
        <button class="btn btn-block mt">Je m'inscris</button>
      </form>
    <?php endif; ?>
    <?php endif; ?>
    <?php if ((int)($org['quotes_enabled'] ?? 1) && strtotime($ev['starts_at']) > time() && empty($ev['_presale_locked'])): ?>
      <a class="group-link" href="<?= url('/e/' . $ev['slug'] . '/groupe') ?>"><span><b>Venir en groupe ?</b><small>À partir de <?= (int)setting('quote_min_' . $org['id'], '10') ?> places : devis, tarif de groupe, paiement par virement</small></span><span aria-hidden="true">→</span></a>
    <?php endif; ?>
  </aside>
</div>
<?php if (!empty($reco)): ?><section class="reco"><h2>Tu aimeras aussi</h2><?php foreach ($reco as $rv) echo view('public/_ev_mini', ['ev' => $rv]); ?></section><?php endif; ?>
<?php if ($seatmap): ?>
<div class="seat-modal" id="seat-modal" hidden>
  <div class="seat-modal-in">
    <div class="row between seat-modal-head"><h2 class="mb0">Plan de salle</h2><button type="button" class="btn btn-sm" id="seat-close">Valider mes places</button></div>
    <div class="seat-legend" id="seat-legend"></div>
    <div class="seat-canvas" id="seat-canvas"><p class="muted">Chargement du plan…</p></div>
    <p class="muted" style="font-size:13.5px;margin:8px 0 0" id="seat-hint">Clique sur une place libre pour la prendre, reclique pour la libérer.</p>
  </div>
</div>
<script src="<?= asset('js/seats.js') ?>"></script>
<?php endif; ?>

<?php if (!empty($useDrawer)): $buyerPre = $_SESSION['buyer'] ?? null; ?>
<div class="dw-backdrop" data-dw-close hidden></div>
<aside class="drawer" id="drawer" hidden aria-label="Réserver mes billets" role="dialog" aria-modal="true"
  data-cart="<?= url($base . '/tiroir/panier') ?>" data-order="<?= url($base . '/tiroir/commande') ?>" data-link="<?= url('/acheteur/lien') ?>" data-back="<?= e($base . ($session ? '?seance=' . (int)$session['id'] : '')) ?>"
  data-csrf="<?= e(csrf_token()) ?>" data-buyer="<?= e(json_encode($buyerPre ? array_intersect_key($buyerPre, array_flip(['first_name', 'last_name', 'email', 'phone'])) : null, JSON_UNESCAPED_UNICODE)) ?>">
  <header class="dw-head">
    <div class="dw-ev"><?php if ($ev['image']): ?><img src="<?= url($ev['image']) ?>" alt=""><?php endif; ?><div><b><?= e($ev['name']) ?></b><small><?= e(fr_date($session['starts_at'] ?? $ev['starts_at'])) ?></small></div></div>
    <button type="button" class="dw-x" data-dw-close aria-label="Fermer">✕</button>
    <ol class="dw-steps"><li data-step="1">Billets</li><li data-step="2">Toi</li><li data-step="3">Récap</li><li data-step="4">Paiement</li></ol>
  </header>
  <div class="dw-body">
    <section class="dw-panel" data-panel="1"><h3 class="dw-h">Choisis tes billets</h3><?php $tiers = Tickets::tiers($ev); if ($tiers): ?><div class="tier-box"><b>Tarif groupe</b> <?= e(implode(' · ', array_map(fn($t) => '−' . $t['pct'] . ' % dès ' . $t['min'] . ' billets', $tiers))) ?><p class="tier-hint" data-tier-hint hidden></p></div><?php endif; ?><div data-slot="rates"></div></section>
    <section class="dw-panel" data-panel="2" hidden>
      <h3 class="dw-h">C'est pour qui ?</h3>
      <form id="dw-buyer" novalidate>
        <div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
        <div class="dw-quick" data-quick><span>Déjà venu ? </span><button type="button" class="link-btn" data-quick-open>Préremplis tes infos avec un lien par e-mail</button>
          <div class="dw-quick-form" hidden><input type="email" placeholder="ton@email.fr" data-quick-mail aria-label="E-mail"><button type="button" class="btn btn-sm" data-quick-send>Envoyer le lien</button></div></div>
        <div class="grid2"><div class="field mb0"><label for="dw-fn">Prénom</label><input id="dw-fn" name="first_name" required autocomplete="given-name"></div>
          <div class="field mb0"><label for="dw-ln">Nom</label><input id="dw-ln" name="last_name" required autocomplete="family-name"></div></div>
        <div class="field mb0"><label for="dw-em">E-mail</label><input id="dw-em" type="email" name="email" required autocomplete="email" inputmode="email"><small data-email-hint>Tes billets arriveront ici.</small></div>
        <div class="field mb0"><label for="dw-ph">Téléphone <small class="muted">(facultatif)</small></label><input id="dw-ph" type="tel" name="phone" autocomplete="tel"></div>
        <div data-slot="fields"></div>
        <label class="check dw-remember"><input type="checkbox" data-remember checked> <span>Me reconnaître sur cet appareil la prochaine fois</span></label>
      </form>
    </section>
    <section class="dw-panel" data-panel="3" hidden>
      <div data-slot="options"></div>
      <div class="dw-recap" data-slot="recap"></div>
      <?php if ($hasCodes || !empty($org['gift_enabled'])): ?><div class="dw-code"><input data-code placeholder="Code promo ou carte cadeau" aria-label="Code promo ou carte cadeau" autocapitalize="characters"><button type="button" class="btn btn-sm btn-light" data-code-apply>Appliquer</button></div><?php endif; ?>
      <label class="check"><input type="checkbox" name="optin" value="1" form="dw-buyer"> <span>Recevoir les prochains événements de <b><?= e($org['name']) ?></b> (désinscription en un clic)</span></label>
      <?php if (setting('cgv')): ?><label class="check"><input type="checkbox" name="cgv" value="1" form="dw-buyer" data-cgv> <span>J'accepte les <a href="<?= url('/cgv') ?>" target="_blank">conditions générales de vente</a></span></label><?php endif; ?>
    </section>
    <section class="dw-panel" data-panel="4" hidden><h3 class="dw-h">Dernière étape</h3><div data-slot="pay"></div></section>
    <div class="dw-errors" data-errors hidden></div>
  </div>
  <footer class="dw-foot">
    <button type="button" class="dw-back" data-dw-back hidden aria-label="Étape précédente">←</button>
    <div class="dw-total"><small data-count>0 billet</small><b data-total>0,00 €</b></div>
    <button type="button" class="btn btn-lg dw-next" data-dw-next>Continuer →</button>
  </footer>
</aside>
<script src="<?= asset('js/drawer.js') ?>"></script>
<?php endif; ?>

<?php if ($anyOnSale || ($sessions && !$session)): ?>
<div class="buy-sticky" data-buy-sticky hidden>
  <div><b><?= e($ev['name']) ?></b><span><?= $fromPrice === null ? 'Choisis ta date' : ($fromPrice === 0 ? 'Gratuit' : 'Dès ' . e(money($fromPrice))) ?></span></div>
  <a class="btn" href="#billets" <?= !empty($useDrawer) ? 'data-dw-open' : '' ?>><?= $sessions && !$session ? 'Choisir' : 'Je réserve' ?></a>
</div>
<?php endif; ?>
